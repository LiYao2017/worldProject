// appid 对应的类型
export default {
  1: {
    type: 'articleDetail'
  },
  2: {
    type: 'photoDetail'
  },
  3: {
    type: 'link'
  },
  4: {
    type: 'videoDetail'
  },
  5: {
    type: 'audioDetail'
  },
  10: {
    type: 'specialTopicList'
  },
  308: {
    type: 'oaArticleDetail'
  },
  3000: {
    type: 'uGCDetail'
  }
};
