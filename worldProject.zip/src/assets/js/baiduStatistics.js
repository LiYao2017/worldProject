(function () {
  try {
    var _hmt = _hmt || [];
    (function () {
      var hm = document.createElement('script');
      hm.src = 'https://hm.baidu.com/hm.js?31604208d2121884912eb4231775f144';
      var s = document.getElementsByTagName('script')[0];
      s.parentNode.insertBefore(hm, s);
    })();
  } catch (e) {
    console.log('百度统计', e);
  }
})();
