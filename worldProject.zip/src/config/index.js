/*
 * @Description: 项目全局设置
 * @Autor: huoyou
 * @Date: 2021-06-03 19:18:58
 * @LastEditTime: 2021-06-11 14:05:57
 */
module.exports.config = {};
