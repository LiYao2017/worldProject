import _utils from '_utils/utils.js';
let state = {
  user: {},
  leaveWords: [
    '我是一条留言',
    '我是一条留言',
    '我是一条留言',
    '我是一条留言',
    '我是一条留言',
    '我是一条留言',
    '我是一条留言',
    '我是一条留言'
  ]
};

export default state;
