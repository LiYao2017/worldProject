## 介绍

该目录下的svg图标会被自动引入svg-icon全局组件使用，详细使用方法参考根目录src/components/svg-icon/SvgIcon.vue。
注意：该目录不可删除！
