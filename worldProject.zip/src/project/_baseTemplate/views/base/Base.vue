<template>
  <div>Base</div>
</template>

<script>
export default {
  name: 'Base'
};
</script>

<style lang="scss" scoped></style>
