export default {
  userinfo(state) {
    return state.userinfo;
  }
};
